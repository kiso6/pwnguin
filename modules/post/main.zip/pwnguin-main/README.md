# pwnguin

Automated pentest framework  
![pwnguinlogo](logo.png)