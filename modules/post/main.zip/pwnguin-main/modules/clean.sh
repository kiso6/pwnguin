#!/usr/bin/bash

# juste pour virer les fichiers relous
rm detect.xml exploit_list list logtest
rm -r __pycache__
rm -r ./edb/mult/*
rm -r ./edb/cgi/*
rm -r ./edb/win/*
rm -r ./edb/lin/*
